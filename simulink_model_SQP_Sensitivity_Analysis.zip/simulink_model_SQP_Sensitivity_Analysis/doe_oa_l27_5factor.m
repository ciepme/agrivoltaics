%% Orthogonal Array DOE (L27) - 5 active factors
% Fixed:
%   phi = 0 rad (due south)
%   z_p = 2.5 m
%
% Active factors (3 levels each):
%   l_p   [m]   : [1.2, 1.5, 1.8]
%   y_p   [m]   : [3.5, 4.0, 4.5]
%   x_p   [m]   : [0.05, 0.10, 0.15]
%   w_p   [m]   : [0.9, 1.0, 1.1]
%   sigma [deg] : [20, 35, 50]
%
% Output:
%   CSV with run settings + emissions + profit

clear;
clc;

base_dir = fileparts(mfilename('fullpath'));
if isempty(base_dir)
    base_dir = pwd;
end
cd(base_dir);

% Initialize model variables exactly as your normal workflow does.
agrivoltaics_variable_definition;
clear variable_bus parameter_bus inequality_constraint_bus equality_constraint_bus;

modelName = "agrivoltaics_v1.slx";
modelBase = "agrivoltaics_v1";

% Avoid re-running InitFcn during each sim call.
origInitFcn = get_param(modelBase, 'InitFcn');
set_param(modelBase, 'InitFcn', '');
init_cleanup = onCleanup(@() set_param(modelBase, 'InitFcn', origInitFcn)); %#ok<NASGU>

% ---------- Factor levels ----------
l_p_levels       = [1.2, 1.5, 1.8];     % m
y_p_levels       = [3.5, 4.0, 4.5];     % m
x_p_levels       = [0.05, 0.10, 0.15];  % m
w_p_levels       = [0.9, 1.0, 1.1];     % m
sigma_deg_levels = [20, 35, 50];        % deg

phi_fixed = 0.0;   % rad
z_p_fixed = 2.5;   % m

% ---------- L27 OA index matrix (levels 1..3) ----------
% Build a valid 27-run OA from three base 3-level columns and two
% additional independent modulo-3 combinations.
[A, B, C] = ndgrid(1:3, 1:3, 1:3);
c1 = A(:);
c2 = B(:);
c3 = C(:);
c4 = mod((c1 - 1) + (c2 - 1), 3) + 1;
c5 = mod((c1 - 1) + (c3 - 1), 3) + 1;
L = [c1, c2, c3, c4, c5];  % 27 x 5

% Map OA indices to physical factor values.
n_runs = size(L, 1);
l_p_vals       = l_p_levels(L(:,1)).';
y_p_vals       = y_p_levels(L(:,2)).';
x_p_vals       = x_p_levels(L(:,3)).';
w_p_vals       = w_p_levels(L(:,4)).';
sigma_deg_vals = sigma_deg_levels(L(:,5)).';
sigma_rad_vals = deg2rad(sigma_deg_vals);

S_out = nan(n_runs, 1);
R_out = nan(n_runs, 1);
total_panels_out = nan(n_runs, 1);
status = strings(n_runs, 1);
error_message = strings(n_runs, 1);

for i = 1:n_runs
    try
        % Apply OA scenario values.
        var.PV.sigma = sigma_rad_vals(i);
        var.PV.phi   = phi_fixed;
        var.PV.z_p   = z_p_fixed;
        var.PV.w_p   = w_p_vals(i);
        var.PV.l_p   = l_p_vals(i);
        var.PV.x_p   = x_p_vals(i);
        var.PV.y_p   = y_p_vals(i);

        % Simulate and read outputs (same approach as housekeeping script).
        simOut = sim(modelName);
        s_data = simOut.yout{1}.Values.Data;
        r_data = simOut.yout{2}.Values.Data;
        tp_obj = [];
        if any(strcmp(simOut.who, 'total_panels'))
            tp_obj = simOut.get('total_panels');
        elseif evalin('base', 'exist(''total_panels'', ''var'')')
            tp_obj = evalin('base', 'total_panels');
        end

        S_out(i) = s_data(end);
        R_out(i) = r_data(end);
        total_panels_out(i) = local_last_numeric(tp_obj);
        status(i) = "ok";
    catch ME
        status(i) = "error";
        error_message(i) = string(getReport(ME, 'extended', 'hyperlinks', 'off'));
    end
end

% Effect calculation (based on level means vs overall mean).
% For OA table, report additive effect sum over the run's factor levels.
effect_co2eq = nan(n_runs, 1);
effect_profit = nan(n_runs, 1);
ok_mask = status == "ok";

if any(ok_mask)
    m_co2 = mean(S_out(ok_mask), 'omitnan');
    m_profit = mean(R_out(ok_mask), 'omitnan');
    level_effect_co2 = nan(5, 3);
    level_effect_profit = nan(5, 3);

    for j = 1:5
        for k = 1:3
            mk = ok_mask & (L(:,j) == k);
            if any(mk)
                level_effect_co2(j,k) = mean(S_out(mk), 'omitnan') - m_co2;
                level_effect_profit(j,k) = mean(R_out(mk), 'omitnan') - m_profit;
            end
        end
    end

    for i = 1:n_runs
        if status(i) ~= "ok"
            continue;
        end
        effect_co2eq(i) = sum(level_effect_co2(sub2ind([5, 3], (1:5).', L(i,:).')), 'omitnan');
        effect_profit(i) = sum(level_effect_profit(sub2ind([5, 3], (1:5).', L(i,:).')), 'omitnan');
    end
end

results = table( ...
    (1:n_runs).', ...
    L(:,1), L(:,2), L(:,3), L(:,4), L(:,5), ...
    sigma_deg_vals, sigma_rad_vals, ...
    repmat(phi_fixed, n_runs, 1), ...
    repmat(z_p_fixed, n_runs, 1), ...
    w_p_vals, l_p_vals, x_p_vals, y_p_vals, ...
    S_out, R_out, effect_co2eq, effect_profit, status, error_message, total_panels_out, ...
    'VariableNames', { ...
    'run_id', ...
    'l_p_level', 'y_p_level', 'x_p_level', 'w_p_level', 'sigma_level', ...
    'sigma_deg', 'sigma_rad', 'phi_rad', 'z_p_m', 'w_p_m', 'l_p_m', 'x_p_m', 'y_p_m', ...
    'total_co2eq_displaced', 'total_profit', 'effect_co2eq', 'effect_profit', ...
    'status', 'error_message', 'total_panels'});

out_csv = fullfile(base_dir, 'doe_oa_l27_5factor_results.csv');
writetable(results, out_csv);

timestamp = char(datetime('now', 'Format', 'yyyyMMdd_HHmmss'));
out_csv_ts = fullfile(base_dir, ['doe_oa_l27_5factor_results_' timestamp '.csv']);
writetable(results, out_csv_ts);

disp('OA DOE finished. Results written to simulink_model folder.');

function v = local_last_numeric(x)
if isempty(x)
    error('total_panels was not found in simulation outputs.');
end
if isa(x, 'timeseries')
    v = double(x.Data(end));
elseif isnumeric(x)
    v = double(x(end));
elseif isstruct(x) && isfield(x, 'signals') && isfield(x.signals, 'values')
    v = double(x.signals.values(end));
else
    error('Unsupported total_panels data type: %s', class(x));
end
end
